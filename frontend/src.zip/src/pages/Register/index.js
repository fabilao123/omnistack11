import React from 'react';

import { Link } from 'react-router-dom';

import { FiArrowLeft } from 'react-icons/fi';

import './styles.css';

import logoImg from '../../assets/logo.svg';

export default function Register() {
    return(
        <div className="register-container">
            
            <div className="content">
                <section>
                    <img src={logoImg} alt="Be The hero"/>
                    <h1> Cadastro </h1>
                    <p>Faça seu cadastro, entre na plataformae ajude pessoas a encontrarem casos da sua ONG.</p>
                    <Link className="back-link" to="/Register">
                        <FiArrowLeft size={16} color="#E02041"/>
                        Não tenho cadastro
                    </Link>                    
                </section>
                <form>
                    <input placeholde="Nome da ONG"/>
                    <input type="email" placeholde="E-mail"/>
                    <input placeholde="WhatsApp"/>

                    <div className="input-group">
                        <input placeholde="Cidade"/>
                        <input placeholde="UF" stile={{ width: 80}}/>
                    </div>
                    <button className="button" type="submit">Cadastrar</button>
                </form>
            </div>
        </div>

    );
    
}